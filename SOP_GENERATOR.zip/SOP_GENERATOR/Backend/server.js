const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();

var corsOptions = {
  origin: "http://localhost:27017"
};

app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(bodyParser.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

const { sendMail } = require("./sendMail/emailTemplate");



app.post('/submit', (req, res) => {
    const formData  = req.body;
    try {
        sendMail(formData?.name, formData?.email, formData?.age, formData?.education, formData?.goal, formData?.institute, formData?.tuition, formData?.experience)
        res.status(200).send({message: 'Appointment sucessfully schuduled.'})
    } catch (error) {
        res.status(500).send({error})
    }
  })

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
