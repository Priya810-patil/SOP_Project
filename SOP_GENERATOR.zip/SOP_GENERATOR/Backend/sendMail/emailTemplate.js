const Sib = require("sib-api-v3-sdk");
const client = Sib.ApiClient.instance;
const apiKey = client.authentications["api-key"];
apiKey.apiKey =
  "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";

const tranEmailApi = new Sib.TransactionalEmailsApi();

const sendMail = (
  name,
  email,
  age,
  education,
  goal,
  institute,
  tuition,
  experience
) => {
  const sender = {
    email: email,
    name: "Google Form",
  };

  const receivers = [
    {
      email: "priyupatil810@gmail.com",
    },
  ];

  tranEmailApi
    .sendTransacEmail({
      sender,
      to: receivers,
      subject: `Statement of Purpose for studying in Canada`,
      textContent: `
            <h3>Dear ${name} </h3>

            <span>
            Please find attched the Statement of Purpose template for your student
            visa application to Canada. Kindly edit it as per your scenario and
            needs.


           Best Regards,
            Team Effizient
            www.effizient.ca
            Ph: 226-774-91
            Email: info@effizient.ca
</span>


        <span>
        From ,<br/>
        ${name} <br/>
         (Address) <br/>
         ${email} <br/>
        
        
        To, <br/>
        Visa Officer <br/>
        High Commission of Canada</span> <br/>
        <span>Dear Sir/Madam</span> <br/>
        <span>
        I would like to take this opportunity to introduce myself as  ${name}, a  ${age}-year-old aspiring student from India. I have recently completed my ${education} in Engineering from ${institute}. Throughout my academic journey, I have developed a strong passion for software development and have gained valuable experience working as an  ${experience}.
                I am writing this statement of purpose to express my interest in pursuing a program of study in Canada. While I have not yet finalized the specific program or education institution, I am confident that Canada offers excellent opportunities for higher education and will provide me with the necessary skills and knowledge to achieve my future goals.
                Canada is renowned for its high-quality education system, which consistently ranks among the best in the world. The interdisciplinary approach to education in Canada is particularly appealing to me, as it will provide me with a comprehensive understanding of various concepts related to software development and related subjects. I believe that studying in Canada will not only enhance my technical skills but also broaden my horizons and expose me to diverse perspectives.
                Furthermore, the education institutions in Canada are known for their experienced and skilled faculties, as well as state-of-the-art facilities. I am confident that studying and working alongside these professionals will greatly contribute to my academic growth and prepare me for a successful career in the field of software development.
                In terms of my academic background, I have successfully completed my Bachelor's Degree ${education}  with a focus on software development. This educational foundation aligns perfectly with my chosen field of study in Canada and will provide me with a solid base to further enhance my knowledge and skills.
                I have also achieved an impressive IELTS score of 10 in listening, 10 in reading, 10 in writing, and 10 in speaking, demonstrating my proficiency in the English language. This language proficiency will undoubtedly contribute to my success in my study program in Canada, as effective communication is crucial in the field of software development.
               In terms of finances, I am fortunate to have the support of my family who will be funding my education in Canada. I have already made the necessary arrangements to pay for the first year's tuition fees ${tuition}, and I am financially capable of supporting my education throughout the duration of the program.
               After completing my study program in Canada, my future goal ${goal} .
                I assure you that if granted the opportunity to study in Canada, I will abide by all the rules and regulations set forth by the Canadian government, the local authorities, and the educational institution. I am fully committed to making the most of this opportunity and to representing my home country in a positive light.
                I kindly request you to consider my application and process my student visa as soon as possible. I have attached all the necessary documents for your review. Thank you for your time and consideration.
               
               
                Best Regards,
                   Team Effizient
                   www.effizient.ca
                   Ph: 226-774-9168
                   Email: info@effizient.ca
</p>
        </span>
        `,
    })
    .then(console.log)
    .catch(console.log);
};

module.exports = {
  sendMail,
};
