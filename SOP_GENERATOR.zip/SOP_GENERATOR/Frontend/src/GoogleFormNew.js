import React, { useState } from 'react';
import axios from 'axios';
import './GoogleFormNew.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min';



export default function GoogleFormNew() {

    const [formData, setFormData] = useState({
        name: '',
        email: '',
        age: '',
        education: '',
        study: '',
        experience: '',
        goal: '',
        institute: '',
        Listening: '',
        Speaking: '',
        Reading: '',
        Writing: '',
        tuition: '',
        fee: '',
        GIC: '',
        pay: ''
    });

    // Handle form input changes
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData({ ...formData, [name]: value });
    };

    // Handle form submission

    const handleSubmit = (event) => {
        event.preventDefault(); // Prevent the default form submission{
        axios.post(`http://localhost:8080/submit`, formData).then(res => {

        }).catch(error => {
        })
    }


    return (
        <form action="" onSubmit={(event) => handleSubmit(event)}>
            <img src="images/icon.PNG" alt="Neeraj Meka" />
            <div class="main">
                <h1>Customized SOP Generator</h1>
                <hr />
                <p style={{ fontSize: "20px" }}>
                    Fill this questionnaire for the student. After submitting, you will receive an email at the email address that you have provided with a Statement of Purpose customized for you. You can use and modify that as per your needs.
                </p>
                <h4 style={{ color: "red" }}>*Indicates required question</h4>
            </div>
            <div class="name">
                <h4>Name <span style={{ color: "red" }}>*</span></h4>
                <input type="text" value={formData.name}
                    onChange={handleInputChange} name="name" id="" placeholder='Your Answer' required />
            </div>
            <div class="email">
                <h4>Email <span style={{ color: "red" }}>*</span></h4>
                <input type="email" value={formData.email}
                    onChange={handleInputChange} name="email" placeholder='Your Email' id="" required />
            </div>
            <div class="Age">
                <h4>Age <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="age"
                    value={formData.age}
                    onChange={handleInputChange}
                    placeholder='Your Age' id="" required />
            </div>
            <div class="Age">
                <h4>Highest Level Of Education <span style={{ color: "red" }}>*</span></h4>
                {/* <input type="text" name="name" placeholder='Your Answer' id="" required /> */}
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        Choose
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="#">Grade 12</a></li>
                        <li><a class="dropdown-item" href="#">Diploma</a></li>
                        <li><a class="dropdown-item" href="#">Bachelor Degree</a></li>
                        <li><a class="dropdown-item" href="#">Master Degree</a></li>
                        <li><a class="dropdown-item" href="#">phd</a></li>
                    </ul>
                </div>
            </div>
            <div class="Age">
                <h4>Institute where you completed your highest level of education
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="education" value={formData.education}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>What did you study<span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="study" value={formData.study}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="experience">
                <h4>Do you have any relevant work experience?</h4>
                <h5>   <br /> <span> Write None if no work experience. Provide the following details if yes:</span>
                    <br /> 1. Job Title
                    <br />2.Company Name
                    <br />3.Job duties
                    <br />Sample Answer: I worked as a Sales Manager at Effizient Immigration Inc from Jan 2022 till Feb 2023. In this role, I managed sales operations, reaching out to leads, lead the outreach program, ensured meeting monthly targets. <span style={{ color: "red" }}>*</span></h5>
                <input type="text" name="experience" value={formData.experience}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>What institute did you get admitted to in Canada?
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="institute" value={formData.institute}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>What are your future goals?
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="goal" value={formData.goal}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>English Scores - Listening
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="Listening" value={formData.Listening}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>English Scores - Reading
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="Reading" value={formData.Reading}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>English Scores - Speaking
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="Speaking" value={formData.Speaking}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>English Scores - Writing
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="Writing" value={formData.Writing}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>Did you pay your first year tuition?
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="tuition" value={formData.tuition}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>How much tuition fee did you pay?
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="fee" value={formData.fee}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="Age">
                <h4>How much did you pay towards GIC?
                    <span style={{ color: "red" }}>*</span></h4>
                <input type="text" name="pay" value={formData.pay}
                    onChange={handleInputChange} placeholder='Your Answer' id="" required />
            </div>
            <div class="submit">
                <button>Submit</button>
            </div>
            <p class="rule">Never submit passwords through Google Forms</p>
            <p class="policy">
                This content is neither created nor endrosed by Google.
                <a href="#">Report Abuse.</a> <a href="#">Terms of condition.</a>
                <a href="#">Privacy Policy.</a>
                <h1 class="Google" style={{ color: "grey; font-weight: 550; width: 50vw" }}>Google Forms</h1>
            </p>
        </form>
    )
}