import logo from './logo.svg';
import './App.css';
import GoogleFormNew from './GoogleFormNew';

function App() {
  return (
    <>
 
   <GoogleFormNew/>
   </>
  );
}

export default App;
